<?php
$con = mysqli_connect("localhost","root","","busbook1") or die(mysql_error());

?>